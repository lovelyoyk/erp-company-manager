# ERP Company Manager

Sistema ERP para gerenciamento de empresa (clientes, funcionários e ordens de serviço).

## Como rodar

```bash
npm install
npm run start
```

Configure o arquivo `.env` corretamente.

---
Rotas:
- POST /api/auth/register
- POST /api/auth/login
- POST /api/clients (autenticado)
- GET /api/clients (autenticado)
- POST /api/employees (admin)
- GET /api/employees (admin)
- POST /api/service-orders (autenticado)
- GET /api/service-orders (autenticado)