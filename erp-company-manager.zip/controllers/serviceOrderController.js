const ServiceOrder = require('../models/ServiceOrder');

exports.createServiceOrder = async (req, res) => {
    try {
        const serviceOrder = await ServiceOrder.create({ ...req.body, createdBy: req.user.id });
        res.status(201).json(serviceOrder);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
};

exports.getServiceOrders = async (req, res) => {
    try {
        const serviceOrders = await ServiceOrder.find().populate('client').populate('createdBy');
        res.json(serviceOrders);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
};