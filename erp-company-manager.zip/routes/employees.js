const express = require('express');
const { createEmployee, getEmployees } = require('../controllers/employeeController');
const auth = require('../middleware/authMiddleware');
const role = require('../middleware/roleMiddleware');
const router = express.Router();

router.post('/', auth, role('admin'), createEmployee);
router.get('/', auth, role('admin'), getEmployees);

module.exports = router;