const express = require('express');
const { createServiceOrder, getServiceOrders } = require('../controllers/serviceOrderController');
const auth = require('../middleware/authMiddleware');
const router = express.Router();

router.post('/', auth, createServiceOrder);
router.get('/', auth, getServiceOrders);

module.exports = router;